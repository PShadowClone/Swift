//
//  ProductCustomCellTable.swift
//  FinalSwfitProject
//
//  Created by i319mac4 on 5/26/16.
//  Copyright © 2016 iug. All rights reserved.
//

import UIKit

class ProductCustomCellTable: UITableViewCell {
    

    @IBOutlet weak var productImage: UIImageView!
    
    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var QProduct: UILabel!
    

}
