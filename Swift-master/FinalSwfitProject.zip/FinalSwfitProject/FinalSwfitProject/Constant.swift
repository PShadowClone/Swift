//
//  Constant.swift
//  FinalSwfitProject
//
//  Created by i219pc11 on 4/30/16.
//  Copyright © 2016 iug. All rights reserved.
//



class Constant
{
     static let PRODUCT_NOT_FOUND = "The product is not existed in this shop"
     static let EMPTY_TRADER_LIST = "There is no traders deal with this user"
     static let WRONG_VALIDATION = "UserName or Password is wrong, please try again"
     static let DONE_MESSAGE = "DONE"
     static let ERROR_MESSAGE = "Something went wrong during login operation, please try again later"
     static let  FILE_NAME = "userInfo.pilst"

    }
